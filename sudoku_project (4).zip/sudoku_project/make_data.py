"""Prepare the digit data (fixed seed).  python make_data.py [--mnist]

Default: scikit-learn's bundled 8x8 digits (works offline).  --mnist downloads real MNIST via scikit-learn."""
import sys

from sudoku import data

if __name__ == "__main__":
    source = data.build(seed=0, mnist="--mnist" in sys.argv)
    d = data.load()
    print("source:", source)
    print({k: len(d[k]) for k in ("ytr", "yva", "yte")}, "->", data.PATH)
