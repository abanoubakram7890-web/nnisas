"""Train the network and the logistic-regression baseline and print the test results."""
from pathlib import Path

from sklearn.metrics import accuracy_score, confusion_matrix, log_loss

from sudoku import nn

if __name__ == "__main__":
    net, d = nn.get_net()
    lr = nn.baseline(d["xtr"], d["ytr"])
    lines = [f"data: {d['source']}   temperature T = {net.T:.2f}", f"{'model':26s} accuracy  log-loss  ECE"]
    for name, p in [("MLP (raw)", net.proba(d["xte"], False)), ("MLP (temperature-scaled)", net.proba(d["xte"])),
                    ("Logistic regression", lr.predict_proba(d["xte"]))]:
        lines.append(f"{name:26s} {accuracy_score(d['yte'], p.argmax(1) + 1):.4f}    "
                     f"{log_loss(d['yte'], p, labels=range(1, 10)):.4f}    {nn.ece(p, d['yte']):.4f}")
    lines.append("confusion matrix of the MLP (rows = true digit 1-9, columns = predicted):")
    lines += [" ".join(f"{v:3d}" for v in row) for row in confusion_matrix(d["yte"], net.predict(d["xte"]))]
    out = Path(__file__).resolve().parent / "results"
    out.mkdir(exist_ok=True)
    (out / "classifier_report.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
