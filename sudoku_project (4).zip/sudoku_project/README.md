# P7 – Handwritten Sudoku Reader and Solver

A neural network (scikit-learn `MLPClassifier`) reads handwritten digits and gives probabilities.
If a digit is misread the puzzle breaks. AC-3 notices the contradiction, a search (UCS / Greedy / A*)
looks for the cheapest digit corrections, and the CSP (Backtracking + Forward Checking + AC-3) checks
each corrected puzzle and solves the first one that works. If nothing works: "unreadable".

**Data note:** MNIST could not be downloaded where this was built, so the default data is scikit-learn's
bundled handwritten digits (8x8 pixels). `python make_data.py --mnist` downloads real MNIST instead
(12,000-image subset); I could not test that option here, so run it yourself before submitting.

## Setup and run (built with Python 3.13; about 4 minutes in total; run the commands inside this folder)

```bash
pip install -r requirements.txt
python make_data.py            # data -> data/digits.npz            (seed 0; also made automatically if missing)
python train_nn.py             # trains network + baseline, prints test results -> results/classifier_report.txt
python -m pytest -q            # 10 tests
python run_experiments.py     # 3 experiments, 5 seeds -> results/tables.txt, experiments.png, *.csv
python run_demo.py             # integrated demo -> text + results/demo.png   (--seed 7 --misreads 2)
```

## Files

| file | what it does |
|---|---|
| `sudoku/data.py`, `make_data.py` | digit data, puzzle generator, mosaic of 81 cell images, hard-digit injection |
| `sudoku/nn.py`, `train_nn.py` | MLP + temperature scaling, logistic-regression baseline, ECE |
| `sudoku/csp.py` | Sudoku CSP: `solve(grid, fc, ac, mrv, cap)`; counters assignments / backtracks / pruned |
| `sudoku/search.py` | UCS, Greedy, A* over correction sets; counters expanded / generated / CSP tests |
| `sudoku/integration.py` | NN -> AC-3 -> search -> CSP (`mode` = nn / none / random) |
| `sudoku/eval.py` | the three experiments |
| `tests/test_project.py` | 5 normal, 3 edge, 2 impossible tests |
| `docs/` | data dictionary, report, notes for the discussion |

## Checklist (first page of the brief)

1 modules ✓ · 2 `make_data.py` ✓ · 3 `docs/DATA_DICTIONARY.md` ✓ · 4 `train_nn.py` (baseline: logistic regression) ✓ ·
5 `search.py` + `test_search_known_answer` ✓ · 6 `csp.py` ✓ · 7 `run_demo.py` ✓ · 8 this file ✓ · 9 `tests/` ✓ ·
10 `results/` ✓ · 11 `docs/REPORT.md` (short draft) · 12 slides: not made, `docs/DISCUSSION_NOTES.md` lists what to show ·
13 contribution statements and git log: yours to write (`git init` and commit this folder).
