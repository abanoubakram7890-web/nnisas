"""Data: handwritten digit images (real) + Sudoku puzzles and mosaics (generated, seeded)."""
import random
from pathlib import Path

import numpy as np
from sklearn.model_selection import train_test_split

from . import csp

PATH = Path(__file__).resolve().parent.parent / "data" / "digits.npz"
BLANK = 0.25        # a cell whose brightest pixel is below this is blank (simple rule, no NN)
MAX_HARD_CONF = 0.90  # an injected hard digit is read with at most this confidence ...
MIN_RUNNER_UP = 0.05  # ... and the true digit still gets at least this probability


# ---------------------------------------------------------------- real data
def build(seed=0, mnist=False):
    """Digits 1-9 as flattened 0-1 images, split 60/20/20 (stratified, fixed seed)."""
    if mnist:   # needs internet; first call downloads about 15 MB
        from sklearn.datasets import fetch_openml
        X, y = fetch_openml("mnist_784", version=1, as_frame=False, return_X_y=True)
        X, y = X / 255.0, y.astype(int)
        keep = np.random.default_rng(seed).permutation(len(y))[:12000]   # subset to keep training fast
        X, y = X[keep], y[keep]
        source, side = "MNIST (12,000-image random subset, 28x28)", 28
    else:       # bundled with scikit-learn, works offline
        from sklearn.datasets import load_digits
        d = load_digits()
        X, y = d.data / 16.0, d.target
        source, side = "scikit-learn load_digits (8x8)", 8
    X, y = X[y != 0], y[y != 0]                                           # drop digit 0
    Xtr, Xrest, ytr, yrest = train_test_split(X, y, train_size=0.6, stratify=y, random_state=seed)
    Xva, Xte, yva, yte = train_test_split(Xrest, yrest, train_size=0.5, stratify=yrest, random_state=seed)
    PATH.parent.mkdir(exist_ok=True)
    np.savez_compressed(PATH, xtr=Xtr, ytr=ytr, xva=Xva, yva=yva, xte=Xte, yte=yte, source=source, side=side)
    return source


def load():
    if not PATH.exists():
        build()
    z = np.load(PATH)
    return {k: z[k] for k in z.files}


# ---------------------------------------------------------------- generated puzzles
def random_solution(rng):
    """Random complete grid: fill the 3 diagonal boxes randomly, let the CSP finish the rest."""
    g = [0] * 81
    for b in range(3):
        for k, d in enumerate(rng.sample(range(1, 10), 9)):
            g[(b * 3 + k // 3) * 9 + b * 3 + k % 3] = d
    return list(csp.solve(g, mrv=True)[0][0])


def make_puzzles(rng, givens_list):
    """Remove cells one by one (random order), keeping a removal only if the solution stays unique.
    Returns (solution, {number_of_givens: puzzle}); the puzzles are nested."""
    targets = sorted(givens_list, reverse=True)
    while True:
        sol = random_solution(rng)
        puz, order, snaps = list(sol), rng.sample(range(81), 81), {}
        n = 81
        for cell in order:
            if n <= targets[-1]:
                break
            old, puz[cell] = puz[cell], 0
            if len(csp.solve(puz, mrv=True, n_solutions=2)[0]) == 1:
                n -= 1
                if n in targets:
                    snaps[n] = list(puz)
            else:
                puz[cell] = old
        if len(snaps) == len(targets):
            return sol, snaps


# ---------------------------------------------------------------- generated mosaics
def make_pool(net, x, y):
    """Test images grouped by digit; 'clean' = the network reads them correctly."""
    pred = net.predict(x)
    return dict(x=x, by_digit={d: np.where(y == d)[0] for d in range(1, 10)},
                clean={d: np.where((y == d) & (pred == d))[0] for d in range(1, 10)})


def hard_digit(net, pool, d, rng):
    """Blend a real image of digit d with a real image of another digit c until the network
    reads c (confidence <= 0.90) with d as runner-up. Returns (image, c)."""
    while True:
        xd = pool["x"][rng.choice(pool["by_digit"][d])]
        c = rng.choice([k for k in range(1, 10) if k != d])
        xc = pool["x"][rng.choice(pool["by_digit"][c])]
        a = rng.choice([0.35 + 0.05 * i for i in range(9)])
        x = (1 - a) * xd + a * xc
        p = net.proba(x)[0]
        top = np.argsort(-p)
        if top[0] + 1 == c and top[1] + 1 == d and p[c - 1] <= MAX_HARD_CONF and p[d - 1] >= MIN_RUNNER_UP:
            return x, c


def make_instance(net, pool, puzzle, k, rng):
    """81 cell images for a puzzle. Given cells show clean real digits, except k injected hard digits.
    Blank cells are dark noise. Returns (cells[81, pixels], [(cell, true_digit, confused_with), ...])."""
    noise = np.random.default_rng(rng.randrange(10 ** 9))
    cells = np.clip(noise.normal(0, 0.01, (81, pool["x"].shape[1])), 0, 0.1)
    bad = rng.sample([i for i in range(81) if puzzle[i]], k)
    misreads = []
    for i in range(81):
        if puzzle[i] == 0:
            continue
        if i in bad:
            cells[i], c = hard_digit(net, pool, puzzle[i], rng)
            misreads.append((i, puzzle[i], c))
        else:
            cells[i] = pool["x"][rng.choice(pool["clean"][puzzle[i]])]
    return cells, misreads
