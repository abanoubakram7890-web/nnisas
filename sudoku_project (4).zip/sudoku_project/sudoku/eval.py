"""Evaluation: the three experiments, 5 seeds each.  python run_experiments.py   (about 3 minutes)

1. UCS vs Greedy vs A*          (nodes, cost, recovery)       for 0-4 misread digits
2. BT vs BT+FC vs BT+FC+AC-3    (assignments, backtracks)     for 35 / 30 / 25 givens
3. NN-guided vs no correction vs random correction            for 0-4 misread digits
Results: results/*.csv (raw), results/tables.txt (mean +- std over seeds), results/experiments.png
"""
import csv
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from . import csp, data, integration, nn

SEEDS, N_PUZZLES = range(5), 20
OUT = Path(__file__).resolve().parent.parent / "results"


def search_runs(net, pool):
    """Experiments 1 and 3 share the same instances; one row per (seed, misreads, puzzle, method)."""
    rows = []
    for seed in SEEDS:
        rng = random.Random(seed)
        puzzles = [data.make_puzzles(rng, [30]) for _ in range(N_PUZZLES)]
        for k in range(5):
            for pi, (sol, snaps) in enumerate(puzzles):
                cells, _ = data.make_instance(net, pool, snaps[30], k, random.Random(seed * 1000 + k * 50 + pi))
                for method, mode, algo, tests in [("UCS", "nn", "ucs", 1500), ("Greedy", "nn", "greedy", 1500),
                                                  ("A*", "nn", "astar", 1500),
                                                  ("A* (NN)", "nn", "astar", 300), ("No correction", "none", "astar", 300),
                                                  ("Random correction", "random", "ucs", 300)]:
                    r = integration.solve_image(cells, net, mode, algo, max_tests=tests, rng=random.Random(pi))
                    s = r["search"] or dict(expanded=0, generated=0, tests=0, cost=0.0)
                    solved = r["status"] == "solved"
                    rows.append(dict(seed=seed, misreads=k, method=method, budget=tests, solved=int(solved),
                                     exact=int(solved and tuple(r["solution"]) == tuple(sol)),
                                     expanded=s["expanded"], generated=s["generated"], tests=s["tests"],
                                     cost=s["cost"] if solved else ""))
    return rows


def csp_runs():
    rows = []
    for seed in SEEDS:
        rng = random.Random(100 + seed)
        for pi in range(10):
            _, snaps = data.make_puzzles(rng, [35, 30, 25])
            for givens, puz in snaps.items():
                for name, fc, ac in [("BT", False, False), ("BT+FC", True, False), ("BT+FC+AC-3", True, True)]:
                    sols, st, _ = csp.solve(puz, fc, ac)
                    rows.append(dict(seed=seed, givens=givens, method=name, assignments=st["assignments"],
                                     backtracks=st["backtracks"], pruned=st["pruned"] + st["ac3_pruned"],
                                     seconds=round(st["seconds"], 4)))
    return rows


def summary(rows, keys, cols, only=lambda r: True):
    """mean +- std over seeds of the per-seed mean."""
    out = {}
    for key in sorted({tuple(r[k] for k in keys) for r in rows if only(r)}, key=lambda t: tuple(map(str, t))):
        per_seed = []
        for seed in SEEDS:
            sel = [r for r in rows if only(r) and r["seed"] == seed and tuple(r[k] for k in keys) == key]
            if sel:
                per_seed.append([np.mean([float(r[c]) for r in sel]) for c in cols])
        out[key] = np.array(per_seed).mean(0), np.array(per_seed).std(0)
    return out


def table(title, header, data_):
    lines = ["", title, " | ".join(header)]
    for key, (m, s) in data_.items():
        lines.append(" | ".join(str(k) for k in key) + " | " + " | ".join(f"{a:.2f}±{b:.2f}" for a, b in zip(m, s)))
    return lines


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    net, d = nn.get_net()
    pool = data.make_pool(net, d["xte"], d["yte"])
    s_rows, c_rows = search_runs(net, pool), csp_runs()
    for name, rows in [("search", s_rows), ("csp", c_rows)]:
        with open(OUT / f"{name}.csv", "w", newline="") as f:
            w = csv.DictWriter(f, rows[0].keys())
            w.writeheader()
            w.writerows(rows)

    e1 = lambda r: r["budget"] == 1500
    e3 = lambda r: r["budget"] == 300
    t1 = summary(s_rows, ["misreads", "method"], ["exact", "solved", "expanded", "generated", "tests"], e1)
    cost = summary(s_rows, ["misreads", "method"], ["cost"], lambda r: e1(r) and r["solved"])
    t2 = summary(c_rows, ["givens", "method"], ["assignments", "backtracks", "pruned", "seconds"])
    t3 = summary(s_rows, ["misreads", "method"], ["exact", "solved", "tests"], e3)
    text = (table("EXPERIMENT 1 (mean±std over 5 seeds; exact/solved are fractions)",
                  ["misreads", "method", "exact", "solved", "expanded", "generated", "CSP tests"], t1)
            + table("  correction cost of the solved cases", ["misreads", "method", "cost"], cost)
            + table("EXPERIMENT 2", ["givens", "method", "assignments", "backtracks", "pruned", "seconds"], t2)
            + table("EXPERIMENT 3 (budget 300 CSP tests)", ["misreads", "method", "exact", "solved", "CSP tests"], t3))
    (OUT / "tables.txt").write_text("\n".join(text) + "\n")
    print("\n".join(text))

    fig, ax = plt.subplots(1, 3, figsize=(15, 4))
    for m in ["UCS", "Greedy", "A*"]:
        ax[0].errorbar(range(5), [t1[(k, m)][0][2] for k in range(5)], [t1[(k, m)][1][2] for k in range(5)], marker="o", label=m)
    ax[0].set(title="Exp 1: nodes expanded", xlabel="misread digits", yscale="symlog"); ax[0].legend()
    for i, m in enumerate(["BT", "BT+FC", "BT+FC+AC-3"]):
        ax[1].bar(np.arange(3) + (i - 1) * 0.27, [t2[(g, m)][0][0] for g in (35, 30, 25)], 0.27, label=m)
    ax[1].set(title="Exp 2: assignments", yscale="log", xticks=range(3), xticklabels=["35 givens", "30", "25"]); ax[1].legend()
    for m in ["A* (NN)", "No correction", "Random correction"]:
        ax[2].errorbar(range(5), [100 * t3[(k, m)][0][0] for k in range(5)], [100 * t3[(k, m)][1][0] for k in range(5)], marker="o", label=m)
    ax[2].set(title="Exp 3: exact recovery (%)", xlabel="misread digits"); ax[2].legend()
    fig.tight_layout()
    fig.savefig(OUT / "experiments.png", dpi=120)
