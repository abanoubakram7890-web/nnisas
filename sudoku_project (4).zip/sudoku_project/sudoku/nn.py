"""Digit classifier: scikit-learn MLPClassifier + temperature scaling, and a logistic-regression baseline."""
import warnings

import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
from sklearn.neural_network import MLPClassifier

from . import data


class Net:
    """One hidden layer of 128 ReLU units. Hyper-parameters (hidden size 64/128, alpha 1e-4/1e-3/1e-2)
    were compared on the validation set. Labels are digits 1-9, so class k means digit k+1."""

    def __init__(self, seed=0):
        self.clf = MLPClassifier(hidden_layer_sizes=(128,), alpha=1e-3, batch_size=64,
                                 learning_rate_init=2e-3, max_iter=300, tol=1e-5,
                                 n_iter_no_change=15, random_state=seed)
        self.T = 1.0

    def _probs(self, X, T):
        z = np.log(np.clip(self.clf.predict_proba(np.atleast_2d(X)), 1e-12, 1)) / T
        e = np.exp(z - z.max(axis=1, keepdims=True))
        return e / e.sum(axis=1, keepdims=True)

    def fit(self, X, y, Xva, yva):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ConvergenceWarning)   # reaching max_iter is fine here
            self.clf.fit(X, y)
        # temperature scaling: the T that gives the lowest validation log-loss makes probabilities honest
        self.T = float(min(np.linspace(0.3, 5, 95),
                           key=lambda T: log_loss(yva, self._probs(Xva, T), labels=range(1, 10))))
        return self

    def proba(self, X, calibrated=True):
        return self._probs(X, self.T if calibrated else 1.0)

    def predict(self, X):
        return self.proba(X).argmax(axis=1) + 1


def get_net():
    """Train the network (about 2 seconds, fixed seed, so always the same) and return it with the data."""
    d = data.load()
    return Net().fit(d["xtr"], d["ytr"], d["xva"], d["yva"]), d


def baseline(Xtr, ytr):
    return LogisticRegression(max_iter=3000).fit(Xtr, ytr)


def ece(p, y, bins=10):
    """Expected calibration error: gap between confidence and accuracy, averaged over confidence bins."""
    conf, ok = p.max(1), (p.argmax(1) + 1 == y)
    edges = np.linspace(0, 1, bins + 1)
    total = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.any():
            total += m.mean() * abs(ok[m].mean() - conf[m].mean())
    return float(total)
