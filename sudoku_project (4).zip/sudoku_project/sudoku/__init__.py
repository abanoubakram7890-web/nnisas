"""Handwritten Sudoku reader and solver: NN + Search + CSP."""
