"""Search for the cheapest set of digit corrections that makes a misread puzzle solvable.

State  : frozenset of (cell, new_digit) corrections applied to the first reading.
Action : change one not-yet-corrected uncertain cell to one of its best alternative digits.
Cost   : log p(read digit) - log p(new digit)   (>= 0 because the read digit was the most probable).
Goal   : the corrected puzzle has no repeated digit and the CSP solves it.
UCS orders by cost so far g; Greedy by (#conflicts, h); A* by g + h.
"""
import heapq
import itertools
import math

import numpy as np

from . import csp


def candidate_moves(probs, read, n_cells=10, n_alt=2):
    """options[cell] = [(new_digit, cost), ...] for the n_cells least confident cells."""
    probs = np.clip(probs, 1e-12, 1)
    given = [i for i in range(81) if read[i]]
    options = {}
    for c in sorted(given, key=lambda i: probs[i][read[i] - 1])[:n_cells]:
        alts = [int(d) + 1 for d in np.argsort(-probs[c]) if d + 1 != read[c]][:n_alt]
        options[c] = [(d, math.log(probs[c][read[c] - 1] / probs[c][d - 1])) for d in alts]
    return options


def estimate(grid, options, used):
    """(h, number of conflicts). h = lower bound on the remaining cost: every repeated digit needs at
    least one more change, and a change costs at least the cheapest option among that conflict's cells.
    Taking the max over conflicts never overestimates (one change may fix several conflicts)."""
    dups = csp.duplicates(grid)
    h = 0
    for _, cells in dups:
        costs = [k for c in cells if c not in used for _, k in options.get(c, [])]
        h = max(h, min(costs, default=math.inf))     # inf = this conflict can no longer be repaired
    return h, len(dups)


def correction_search(read, options, algo="astar", max_corrections=3, max_tests=1500):
    """Returns a dict: status ('solved' / 'unreadable'), corrections, cost, solution, grid, and the
    counters expanded / generated / tests (= CSP goal tests)."""
    out = dict(status="unreadable", corrections=[], cost=None, solution=None, grid=None,
               expanded=0, generated=1, tests=0, trace=[], message="no correction set works")
    cost_of = {(c, d): k for c, lst in options.items() for d, k in lst}
    count = itertools.count()                          # tie-breaker so the heap never compares states

    def prio(g, h, n):
        return {"ucs": (g,), "greedy": (n, h), "astar": (g + h,)}[algo]

    start = frozenset()
    h0, n0 = estimate(read, options, set())
    frontier = [(prio(0, h0, n0), next(count), 0.0, start)]
    seen = {start}
    while frontier:
        if out["tests"] >= max_tests:
            out["message"] = f"stopped after {max_tests} goal tests"
            break
        _, _, g, state = heapq.heappop(frontier)
        out["expanded"] += 1
        grid = list(read)
        for c, d in state:
            grid[c] = d
        out["tests"] += 1
        sols = [] if csp.duplicates(grid) else csp.solve(grid, mrv=True, cap=200_000)[0]
        out["trace"].append((round(g, 3), sorted(state), bool(sols)))
        if sols:
            out.update(status="solved", cost=g, solution=sols[0], grid=grid, message="ok",
                       corrections=[(c, read[c], d, cost_of[(c, d)]) for c, d in sorted(state)])
            break
        if len(state) == max_corrections:
            continue
        used = {c for c, _ in state}
        for c, lst in options.items():
            if c in used:
                continue
            for d, k in lst:
                new = state | {(c, d)}
                if new in seen:
                    continue
                seen.add(new)
                ngrid = list(grid)
                ngrid[c] = d
                h, n = estimate(ngrid, options, used | {c})
                if algo == "astar" and h == math.inf:
                    continue                             # dead end: a conflict that cannot be repaired
                out["generated"] += 1
                heapq.heappush(frontier, (prio(g + k, h, n), next(count), g + k, new))
    return out
