"""Sudoku as a CSP: Backtracking, with Forward Checking (FC) and AC-3 as optional switches.

Variables: the 81 cells (index = row*9 + col).  Domains: sets of digits 1-9.
Constraint: two cells in the same row, column or box must differ.
"""
import time
from collections import deque

UNITS = ([[r * 9 + c for c in range(9)] for r in range(9)]                       # rows
         + [[r * 9 + c for r in range(9)] for c in range(9)]                     # columns
         + [[(br * 3 + r) * 9 + bc * 3 + c for r in range(3) for c in range(3)]  # boxes
            for br in range(3) for bc in range(3)])
PEERS = [sorted({p for u in UNITS if i in u for p in u} - {i}) for i in range(81)]


def duplicates(grid):
    """Digits repeated inside a row/column/box: [(digit, [cells]), ...]."""
    out = []
    for u in UNITS:
        for d in {grid[c] for c in u} - {0}:
            cells = [c for c in u if grid[c] == d]
            if len(cells) > 1:
                out.append((d, cells))
    return out


def is_solution(grid):
    return all(sorted(grid[c] for c in u) == list(range(1, 10)) for u in UNITS)


def initial_domains(grid):
    return [{v} if v else set(range(1, 10)) for v in grid]


def ac3(dom, st):
    """AC-3 on all 'not equal' arcs. Returns False if some domain becomes empty."""
    queue = deque((a, b) for a in range(81) for b in PEERS[a])
    while queue:
        a, b = queue.popleft()
        st["ac3_revisions"] += 1
        # b has only one possible digit, so a cannot use it
        if len(dom[b]) == 1 and dom[a] & dom[b]:
            dom[a] = dom[a] - dom[b]
            st["ac3_pruned"] += 1
            if not dom[a]:
                return False
            queue.extend((c, a) for c in PEERS[a] if c != b)  # a changed: re-check its neighbours
    return True


def ac3_conflict(grid):
    """True if AC-3 proves the givens contradict each other."""
    st = dict(ac3_revisions=0, ac3_pruned=0)
    return not ac3(initial_domains(grid), st)


def forward_check(dom, g, i, v, st):
    """Remove digit v from the domains of i's empty peers. False if a domain becomes empty."""
    for p in PEERS[i]:
        if g[p] == 0 and v in dom[p]:
            dom[p].discard(v)
            st["pruned"] += 1
            if not dom[p]:
                return False
    return True


class Cap(Exception):
    pass


def solve(grid, fc=True, ac=True, mrv=False, cap=None, n_solutions=1):
    """Backtracking search (0 = empty cell).

    fc  : forward checking after every assignment
    ac  : run AC-3 once before the search
    mrv : pick the empty cell with the smallest domain (default: first empty cell)
    cap : stop after this many assignments
    Returns (solutions, stats, message).  stats has the counters assignments / backtracks / ...
    """
    t0 = time.perf_counter()
    st = dict(assignments=0, backtracks=0, pruned=0, ac3_revisions=0, ac3_pruned=0, capped=False)
    g = list(grid)
    dom = initial_domains(g)
    if ac:
        if not ac3(dom, st):
            return [], st, "no solution: AC-3 emptied a domain (the givens contradict each other)"
    elif duplicates(g):
        return [], st, "no solution: a digit is repeated inside a row, column or box"
    elif fc:
        for i in range(81):
            if g[i] and not forward_check(dom, g, i, g[i], st):
                return [], st, "no solution: a cell has no legal digit left"

    sols = []

    def rec(dom):
        free = [i for i in range(81) if g[i] == 0]
        if not free:
            sols.append(tuple(g))
            return len(sols) >= n_solutions
        i = min(free, key=lambda c: len(dom[c])) if mrv else free[0]
        for v in sorted(dom[i]):
            if not fc and any(g[p] == v for p in PEERS[i]):
                continue                          # plain BT: check the assignment against the grid
            if cap and st["assignments"] >= cap:
                raise Cap()
            st["assignments"] += 1
            g[i] = v
            if fc:
                new = [set(d) for d in dom]       # copy so that we can undo the pruning
                new[i] = {v}
                if forward_check(new, g, i, v, st) and rec(new):
                    return True
            elif rec(dom):
                return True
            g[i] = 0                              # undo
            st["backtracks"] += 1
        return False

    try:
        rec(dom)
    except Cap:
        st["capped"] = True
        return sols, st, "stopped: assignment cap reached"
    finally:
        st["seconds"] = time.perf_counter() - t0
    return sols, st, "ok" if sols else "no solution: the search tried everything"
