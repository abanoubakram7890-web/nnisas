"""The three parts together:  NN reads  ->  AC-3 checks  ->  Search proposes corrections  ->  CSP tests/solves.

mode 'nn'     : correction costs come from the network's probabilities
mode 'none'   : no correction, just try to solve the first reading
mode 'random' : random candidate cells, digits and costs (control experiment)
"""
import random

import numpy as np

from . import csp, search
from .data import BLANK


def read_cells(cells, net):
    """Blank cells (dark) -> 0, otherwise the network's most probable digit. Also returns the probabilities."""
    blank = cells.max(axis=1) < BLANK
    probs = np.zeros((81, 9))
    probs[~blank] = net.proba(cells[~blank])
    return [0 if blank[i] else int(probs[i].argmax()) + 1 for i in range(81)], probs


def solve_image(cells, net, mode="nn", algo="astar", max_corrections=3, max_tests=1500, rng=None):
    read, probs = read_cells(cells, net)
    res = dict(read=read, status="unreadable", solution=None, corrections=[], search=None,
               conflict=csp.ac3_conflict(read), message="")
    sols = csp.solve(read, mrv=True, cap=200_000)[0]          # first try without any correction
    if sols:
        return {**res, "status": "solved", "solution": sols[0], "message": "first reading already solvable"}
    least = sorted((i for i in range(81) if read[i]), key=lambda i: probs[i][read[i] - 1])[:5]
    res["least_confident"] = [(i // 9 + 1, i % 9 + 1, read[i], round(float(probs[i][read[i] - 1]), 2)) for i in least]
    if mode == "none":
        res["message"] = "unreadable: the first reading has no solution and correction is switched off"
        return res
    if mode == "nn":
        options = search.candidate_moves(probs, read)
    else:
        rng = rng or random.Random(0)
        options = {c: [(d, rng.random()) for d in rng.sample([x for x in range(1, 10) if x != read[c]], 2)]
                   for c in range(81) if read[c]}
        algo = "ucs"
    s = search.correction_search(read, options, algo, max_corrections, max_tests)
    res["search"] = s
    if s["status"] == "solved":
        res.update(status="solved", solution=s["solution"], corrections=s["corrections"],
                   message=f"solved with {len(s['corrections'])} correction(s)")
    else:
        res["message"] = (f"unreadable: no solvable puzzle within {max_corrections} corrections. "
                          f"Least confident cells (row, col, read digit, probability): {res['least_confident']}")
    return res
