"""Runs the three experiments (the code is in sudoku/eval.py). Works from any folder."""
import runpy

runpy.run_module("sudoku.eval", run_name="__main__")
