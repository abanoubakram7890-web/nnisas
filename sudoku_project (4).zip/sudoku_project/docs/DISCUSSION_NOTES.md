# Notes for the discussion (read these, then open the code and trace it yourself)

## The whole idea in 4 sentences
The network turns each cell image into 9 probabilities. If the best guesses break a Sudoku rule, AC-3 sees it.
Search then tries small sets of "change this cell to its second-best digit", cheapest (most likely) first.
For each set the CSP checks whether the puzzle can be solved; the first one that can is the answer.

## Where to look
| question | file / function |
|---|---|
| how is Sudoku a CSP? | `csp.py` top: UNITS, PEERS (a cell must differ from its 20 peers) |
| what does AC-3 do here? | `csp.ac3`: if a peer has only one possible digit, remove it from this cell; empty domain = contradiction |
| what does Forward Checking do? | `csp.forward_check`: after assigning v, remove v from the empty peers; empty domain = backtrack now |
| how are FC / AC-3 switched? | arguments `fc`, `ac` of `csp.solve` |
| what is a search state, action, cost, goal? | docstring of `search.py` |
| why is the A* heuristic admissible? | `search.estimate`: each conflict needs >= 1 more change and a change costs >= the cheapest option of that conflict's cells; the max over conflicts never overestimates |
| why do UCS and A* give the same cost? | both are optimal; A* just expands fewer nodes |
| why temperature scaling? | `nn.Net.fit`: costs are log-probabilities, so over-confident probabilities give bad costs |
| what is ECE? | `nn.ece`: average gap between confidence and accuracy |

## Questions you may get
* **Why not just pick the top digit?** One wrong digit makes the puzzle unsolvable (experiment 3, "no correction": 0 %).
* **Why is "solved" not always right?** Several correction sets can give a solvable puzzle; we take the cheapest, not necessarily the true one (61 % for 3 misreads).
* **What if the network is confidently wrong?** The cell is not in the 10-cell shortlist, so it can never be fixed. This is a limit.
* **Why 3 corrections max, 10 cells, 2 alternatives?** To keep the search small. With 4 misreads the limit is too low (0 % exact).
* **Is the data real?** Digits are real. Puzzles are generated (unique solution). The 81-cell pictures are assembled from real digit images and the hard digits are blends I made on purpose. Say this openly.
* **Why not MNIST?** Download was blocked here; `make_data.py --mnist` is there but untested.
* **What would you change?** Uniqueness check in the goal test, MAC (AC-3 during search), real photographs, run on MNIST.

## Live demo order (item 12 of the checklist)
`python run_demo.py`: input and NN reading -> AC-3 conflict -> search trace (A* vs UCS vs Greedy) -> CSP pruning table (BT / +FC / +AC-3) -> NN ON vs OFF -> solution.
Try `--seed 3 --misreads 3` for a harder example.
