# Data dictionary

## Real data
`data/digits.npz` (made by `make_data.py`, seed 0). Default source: scikit-learn `load_digits`
(UCI handwritten digits, 8x8 pixels). Digit 0 is removed because Sudoku has no 0.

| array | shape | meaning |
|---|---|---|
| `xtr`, `xva`, `xte` | (971, 64), (324, 64), (324, 64) | image, 64 pixels scaled to 0-1 (**real**) |
| `ytr`, `yva`, `yte` | same N | digit 1-9 (**real**) |
| `source`, `side` | text, int | where the images came from, image width |

Split: 60 % train / 20 % validation / 20 % test, stratified by digit. No personal data exists in it.

## Generated data (all seeded)
| what | how it is made |
|---|---|
| Sudoku solution | the 3 diagonal boxes are filled with random digits, then the CSP completes the grid |
| puzzle | cells are removed in random order; a removal is kept only if the puzzle still has exactly one solution (checked with the CSP). Results use 25, 30 and 35 givens |
| mosaic (81 cell images) | each given cell is a random real test image of its digit that the network reads correctly; each blank cell is dark noise (normal, sigma 0.01, clipped to 0.1). A cell is called blank by a brightness rule (brightest pixel < 0.25), not by the network |
| hard digit (the injected misreads) | blend `(1-a)*image of true digit d + a*image of other digit c`, a from 0.35 to 0.75. Accepted only if the network's top answer is c with probability <= 0.90 and d is second with probability >= 0.05 |

So the mosaics are real digit pixels combined by a rule, not photographs of Sudoku sheets, and only the
injected digits are misread (the network's own test errors, about 2 %, are reported separately).

## Result files
`results/search.csv`: seed, misreads, method, budget (max CSP tests), solved, exact (equals the true solution), expanded, generated, tests, cost.
`results/csp.csv`: seed, givens, method, assignments, backtracks, pruned, seconds.
