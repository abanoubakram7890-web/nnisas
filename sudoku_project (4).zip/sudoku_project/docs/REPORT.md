# P7 – Handwritten Sudoku Reader and Solver (short report draft)

*Numbers are from the 8x8 digits fallback (MNIST was not reachable). Re-run on MNIST and check them before submitting.*

## 1. Problem
A Sudoku written by hand is read by a neural network. One misread digit usually makes the puzzle
contradictory. The system must notice this, find the most likely corrections, solve the puzzle, or say
clearly that it is unreadable.

## 2. Design choices
* **Network.** scikit-learn MLP (one hidden layer, 128 ReLU units, Adam). Hidden size and L2 penalty were chosen on the validation set.
  Temperature scaling (T = 1.30) makes the probabilities more honest, which matters because the search cost is built from them.
* **CSP.** 81 variables, domain 1-9, "not equal" constraints inside rows, columns and boxes. Backtracking is always used; Forward Checking
  and AC-3 are separate switches. AC-3 also detects contradictory givens.
* **Search.** A state is a set of corrections to the first reading (at most 3). One move changes one of the 10 least confident cells to one of its
  2 next-best digits. Cost of a move = log p(read digit) - log p(new digit), so a likely correction is cheap. The goal test is "no repeated digit and
  the CSP can solve it". A* uses h = the largest, over all repeated-digit conflicts, of the cheapest remaining correction among that conflict's cells.
  Every conflict needs at least one more change, so h never overestimates.
* **Integration.** NN reads -> try to solve the reading as it is -> otherwise search proposes corrections and the CSP tests each -> first solvable wins -> if none: "unreadable" and the 5 least confident cells.

## 3. Neural network (324 test images)
| model | accuracy | log-loss | ECE |
|---|---|---|---|
| MLP, raw | 97.8 % | 0.116 | 0.021 |
| MLP, temperature-scaled | 97.8 % | 0.099 | 0.017 |
| Logistic regression (baseline) | 96.0 % | 0.186 | 0.074 |

The MLP is a little more accurate than the baseline (7 vs 13 errors, a small test set) and its probabilities are better calibrated.

## 4. Experiments (5 seeds, mean ± std; full tables in `results/tables.txt`, plot in `results/experiments.png`)

**1. UCS vs Greedy vs A*** (30 givens, 20 puzzles per seed). Nodes expanded:

| misreads | UCS | Greedy | A* | exact solution found (A*) |
|---|---|---|---|---|
| 1 | 2.1 | 1.8 | 1.8 | 90 % |
| 2 | 5.7 | 3.5 | 3.7 | 76 % |
| 3 | 15.8 | 5.5 | 7.2 | 61 % |
| 4 | 532 | 503 | 125 | 0 % |

A* and UCS always return the same (minimum) cost; A* needs fewer nodes. Greedy expands few nodes but its correction cost is higher
(3.26 vs 3.07 for 3 misreads) and it finds the true solution less often (52 % vs 61 %).

**2. BT vs BT+FC vs BT+FC+AC-3** (assignments, 10 puzzles per seed, no cap; the 25-given averages vary a lot between puzzles):

| givens | BT | + FC | + FC + AC-3 |
|---|---|---|---|
| 35 | 863 | 278 | 134 |
| 30 | 4,320 | 1,155 | 629 |
| 25 | 69,883 | 13,899 | 5,843 |

**3. NN-guided vs no correction vs random correction** (300 CSP tests budget). Exact solution found:

| misreads | A* with NN | no correction | random correction |
|---|---|---|---|
| 1 | 90 % | 0 % | 2 % |
| 2 | 76 % | 0 % | 2 % |
| 3 | 61 % | 0 % | 0 % |

## 5. Limits
* **Solvable is not correct.** With 1-3 misreads the system always finds a solvable puzzle, but only 90 / 76 / 61 % of the time is it the true one:
  a cheaper wrong correction can also be solvable. With 4 misreads (limit 3 corrections) it still "solves" 57 % of puzzles, all wrongly.
  Requiring a unique solution would help but is not implemented.
* The method can only repair digits the network is unsure about; a confidently wrong digit never reaches the 10-cell shortlist.
* Data: 8x8 digits, and mosaics built from real digit images by a rule, not photographs of Sudoku sheets. The hard digits are produced by my blending rule.
* Not done: MNIST run, a statistical test between algorithms, maintaining arc consistency during the search.

## 6. Conclusions
Calibrated probabilities turn "the puzzle is broken" into a ranked list of plausible repairs. A* finds the cheapest repair with fewer nodes than UCS,
FC and AC-3 make every solvability check cheaper, and without the network's probabilities correction either never happens or is random.
The system should report that answers are unreliable once more digits are misread than corrections are allowed.
