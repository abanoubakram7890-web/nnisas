"""python -m pytest -q   (5 normal, 3 edge, 2 impossible tests)"""
import functools
import math
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from sudoku import csp, data, integration, nn, search  # noqa: E402

PUZ = [int(c) for c in "530070000600195000098000060800060003400803001700020006060000280000419005000080079"]
SOL = tuple(int(c) for c in "534678912672195348198342567859761423426853791713924856961537284287419635345286179")


@functools.lru_cache(maxsize=None)
def trained():
    return nn.get_net()


def probs_for(grid, p=0.97):
    out = [[(1 - p) / 8] * 9 for _ in range(81)]
    for i, v in enumerate(grid):
        if v:
            out[i][v - 1] = p
    return out


# ---------------- normal cases
def test_csp_known_answer():
    assert csp.solve(PUZ)[0][0] == SOL


def test_csp_all_switches_agree_and_pruning_helps():
    runs = [csp.solve(PUZ, fc, ac) for fc, ac in [(False, False), (True, False), (True, True)]]
    assert all(r[0][0] == SOL for r in runs)
    a = [r[1]["assignments"] for r in runs]
    assert a[0] > a[1] > a[2]


def test_search_known_answer():
    """Cell 1 holds a 3 that was read as 5 (probability .50 vs .45): row 1 then has two 5s."""
    read = list(PUZ)
    read[1] = 5
    probs = probs_for(read)
    probs[1] = [0.0025] * 9
    probs[1][4], probs[1][2] = 0.50, 0.45
    options = search.candidate_moves(__import__("numpy").array(probs), read)
    for algo in ["ucs", "greedy", "astar"]:
        r = search.correction_search(read, options, algo)
        assert r["status"] == "solved" and r["solution"] == SOL
        assert r["corrections"][0][:3] == (1, 5, 3) and math.isclose(r["cost"], math.log(0.5 / 0.45))
        assert r["expanded"] >= 1 and r["generated"] >= r["expanded"]


def test_network_beats_baseline_or_close():
    net, d = trained()
    acc = (net.predict(d["xte"]) == d["yte"]).mean()
    base = nn.baseline(d["xtr"], d["ytr"]).score(d["xte"], d["yte"])
    assert acc > 0.9 and acc >= base - 0.02


def test_pipeline_recovers_one_misread():
    net, d = trained()
    pool = data.make_pool(net, d["xte"], d["yte"])
    ok = 0
    for s in range(6):
        rng = random.Random(s)
        sol, snaps = data.make_puzzles(rng, [32])
        cells, _ = data.make_instance(net, pool, snaps[32], 1, rng)
        r = integration.solve_image(cells, net)
        assert r["status"] == "solved" and csp.is_solution(list(r["solution"]))
        ok += tuple(r["solution"]) == tuple(sol)
    assert ok >= 4


# ---------------- edge cases
def test_edge_complete_grid():
    sols, st, _ = csp.solve(list(SOL))
    assert sols[0] == SOL and st["assignments"] == 0


def test_edge_empty_grid_has_many_solutions():
    sols, _, _ = csp.solve([0] * 81, mrv=True, n_solutions=2)
    assert len(sols) == 2 and all(csp.is_solution(list(s)) for s in sols)


def test_edge_zero_corrections_allowed_and_assignment_cap():
    read = list(PUZ)
    read[1] = 5
    options = search.candidate_moves(__import__("numpy").array(probs_for(read)), read)
    assert search.correction_search(read, options, max_corrections=0)["status"] == "unreadable"
    assert csp.solve([0] * 81, fc=False, ac=False, cap=50)[1]["capped"]


# ---------------- impossible cases (must give a clear message)
def test_impossible_repeated_digit():
    g = list(PUZ)
    g[2] = 5                                   # second 5 in row 1
    for fc, ac in [(True, True), (False, False)]:
        sols, _, msg = csp.solve(g, fc, ac)
        assert sols == [] and msg.startswith("no solution")


def test_impossible_contradictory_puzzle_says_unreadable():
    """Two clean, confidently read 5s in one row and no correction allowed: the system must say so."""
    net, d = trained()
    pool = data.make_pool(net, d["xte"], d["yte"])
    rng = random.Random(5)
    puz = list(PUZ)
    puz[2] = 5                                                    # contradicts the 5 already in row 1
    cells, _ = data.make_instance(net, pool, puz, 0, rng)
    r = integration.solve_image(cells, net, max_corrections=0)
    assert r["status"] == "unreadable" and r["message"].startswith("unreadable") and len(r["least_confident"]) == 5
    assert r["conflict"]                                          # AC-3 noticed the contradiction
