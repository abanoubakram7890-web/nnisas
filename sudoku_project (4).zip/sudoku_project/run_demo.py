"""Integrated demo:  python run_demo.py [--seed 7] [--misreads 2]

Shows the input, the network's reading, the AC-3 conflict, the search trace (UCS / Greedy / A*),
CSP pruning with and without FC / AC-3, the system with the NN on versus off, and the solution.
Figure: results/demo.png
"""
import argparse
import random
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from sudoku import csp, data, integration, nn, search


def show(g, marks=()):
    rows = []
    for r in range(9):
        row = "".join((f"[{g[r*9+c]}]" if r * 9 + c in marks else f" {g[r*9+c] or '.'} ") + ("|" if c in (2, 5) else "") for c in range(9))
        rows += [row] + (["-" * 29] if r in (2, 5) else [])
    return "\n".join(rows)


def draw(ax, g, title, red=(), blue=()):
    ax.set(xlim=(0, 9), ylim=(9, 0), xticks=[], yticks=[], title=title, aspect="equal")
    for k in range(10):
        ax.axhline(k, color="k", lw=2 if k % 3 == 0 else 0.4)
        ax.axvline(k, color="k", lw=2 if k % 3 == 0 else 0.4)
    for i, v in enumerate(g):
        if v:
            ax.text(i % 9 + .5, i // 9 + .55, v, ha="center", va="center", fontsize=11,
                    color="#d62728" if i in red else "#1f77b4" if i in blue else "k")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--misreads", type=int, default=2)
    a = ap.parse_args()
    net, d = nn.get_net()
    pool = data.make_pool(net, d["xte"], d["yte"])

    # pick a seed where the first reading is wrong, A* repairs it and the system without the NN fails
    for attempt in range(100):
        rng = random.Random(a.seed * 1000 + attempt)
        sol, snaps = data.make_puzzles(rng, [30])
        cells, mis = data.make_instance(net, pool, snaps[30], a.misreads, rng)
        on = integration.solve_image(cells, net, "nn", "astar")
        off = integration.solve_image(cells, net, "none")
        if on["status"] == "solved" and tuple(on["solution"]) == tuple(sol) and off["status"] != "solved":
            break
    bad = {m[0] for m in mis}
    read = on["read"]
    print("INPUT puzzle (what was written):\n" + show(snaps[30]))
    print(f"\nNN FIRST READING ([x] = misread, {a.misreads} injected hard digits):\n" + show(read, bad))
    print("\nAC-3 on the reading:", "CONFLICT, so something was misread" if on["conflict"] else "no conflict")
    for dgt, cells_ in csp.duplicates(read)[:3]:
        print(f"  digit {dgt} repeated at (row, col) {[(c // 9 + 1, c % 9 + 1) for c in cells_]}")

    _, probs = integration.read_cells(cells, net)
    options = search.candidate_moves(probs, read)
    runs = {algo: search.correction_search(read, options, algo) for algo in ["ucs", "greedy", "astar"]}
    print("\nSEARCH    expanded generated CSP-tests cost")
    for algo, r in runs.items():
        print(f"  {algo:7s} {r['expanded']:8d} {r['generated']:9d} {r['tests']:9d} {r['cost']:.3f}")
    print("\nA* trace (cost so far, corrections tried, did the CSP solve it?):")
    for i, (g, state, ok) in enumerate(runs["astar"]["trace"], 1):
        print(f"  {i:2d}. g={g:5.3f}  {state}  {'SOLVED' if ok else 'no'}")
    print("\nCORRECTIONS (row, col, read -> new, cost):")
    for c, old, new, k in on["corrections"]:
        print(f"  ({c // 9 + 1}, {c % 9 + 1})  {old} -> {new}   {k:.3f}   (true digit: {sol[c]})")

    print("\nCSP PRUNING on the corrected puzzle and on a 26-given puzzle:")
    hard = data.make_puzzles(random.Random(a.seed), [26])[1][26]
    fixed = list(read)
    for c, _, new, _ in on["corrections"]:
        fixed[c] = new
    counts = {}
    for name, g in [("corrected puzzle", fixed), ("26 givens", hard)]:
        for label, fc, ac in [("BT", False, False), ("BT+FC", True, False), ("BT+FC+AC-3", True, True)]:
            st = csp.solve(g, fc, ac)[1]
            counts[name, label] = st["assignments"]
            print(f"  {name:17s} {label:11s} assignments={st['assignments']:6d} backtracks={st['backtracks']:6d} "
                  f"pruned={st['pruned'] + st['ac3_pruned']:5d}")

    print(f"\nNN ON : {on['status']}, equals the true solution: {tuple(on['solution']) == tuple(sol)}")
    print(f"NN OFF: {off['status']}. {off['message'][:90]}...")
    print("\nSOLUTION:\n" + show(on["solution"]))

    fig, ax = plt.subplots(2, 3, figsize=(15, 9.5))
    side = int(d["side"])
    ax[0, 0].imshow(np.vstack([np.hstack([cells[r * 9 + c].reshape(side, side) for c in range(9)]) for r in range(9)]),
                    cmap="gray_r", interpolation="nearest")
    ax[0, 0].set(title="input images (hard digits: " + ", ".join(f"({c // 9 + 1},{c % 9 + 1})" for c in sorted(bad)) + ")",
                 xticks=[], yticks=[])
    draw(ax[0, 1], read, "NN reading (red = misread, AC-3 sees a conflict)", red=bad)
    draw(ax[0, 2], fixed, "after search + CSP check (blue = corrected)", blue={c[0] for c in on["corrections"]})
    colors = dict(ucs="#1f77b4", greedy="#d62728", astar="#2ca02c")
    for algo, r in runs.items():
        ax[1, 0].plot([t[0] for t in r["trace"]], "o-", ms=3, label=f"{algo.upper()} ({r['expanded']} expanded)", color=colors[algo])
    ax[1, 0].set(title="search trace: cost of each expanded state", xlabel="expansion", ylabel="g")
    ax[1, 0].legend()
    for i, name in enumerate(["corrected puzzle", "26 givens"]):
        ax[1, 1].bar(np.arange(3) + (i - .5) * .35, [counts[name, m] for m in ["BT", "BT+FC", "BT+FC+AC-3"]], .35, label=name)
    ax[1, 1].set(title="CSP pruning: assignments", xticks=range(3), xticklabels=["BT", "BT+FC", "BT+FC+AC-3"], yscale="log")
    ax[1, 1].legend()
    draw(ax[1, 2], list(on["solution"]), f"solution (NN ON: solved;  NN OFF: {off['status']})", blue={i for i in range(81) if not fixed[i]})
    fig.tight_layout()
    out = Path(__file__).resolve().parent / "results"
    out.mkdir(exist_ok=True)
    fig.savefig(out / "demo.png", dpi=110)
    print("\nfigure saved to", out / "demo.png")
